python manage.py loaddata fixtures/user.json
python manage.py loaddata fixtures/account.json
python manage.py loaddata fixtures/socialaccount.json
python manage.py loaddata fixtures/preferences.json
