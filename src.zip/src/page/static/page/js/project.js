$(document).ready(function(){

    $("#scrollHide").overlayScrollbars({ 
        className       : "os-theme-dark",
        resize          : "both",
        sizeAutoCapable : true,
        paddingAbsolute : true
    });
});
